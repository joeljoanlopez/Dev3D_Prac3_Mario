# Fix error on console

- Go to Mario object to the animation
- Delete events in the animation
