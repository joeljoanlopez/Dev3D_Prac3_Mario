using UnityEngine;

public class WallJump : MonoBehaviour
{

}