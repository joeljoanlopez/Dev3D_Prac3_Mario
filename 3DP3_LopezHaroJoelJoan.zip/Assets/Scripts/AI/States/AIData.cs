﻿using System;
using UnityEngine;
using UnityEngine.AI;

public class AIData : MonoBehaviour
{
	public Transform playerTransform;
	public Transform path;
	public int currentNodeIndex = 0;
}